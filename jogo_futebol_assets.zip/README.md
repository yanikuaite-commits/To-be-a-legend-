# Assets do jogo de futebol — personagens chibi

40 personagens (14 "casual" + 13 "football" + 13 "base") prontos para o motor do jogo, com:
- sprites individuais com fundo transparente
- camadas separadas de **pele**, **cabelo** e **corpo/roupa** (personalização)
- biblioteca de **40 cabelos** trocáveis entre personagens
- **rig de 4 peças** (head, torso, leg_l, leg_r) com pivots para animar
- ferramentas Python e JS para compor/cortar

Tudo está num canvas único de **256×512 px**, pés na linha **y = 500**, centro em **x = 128**
(escala igual nos dois conjuntos, por isso podes trocar de personagem sem reposicionar).

## Estrutura
```
characters/casual/casual_01..14.png        sprite completo
characters/football/football_01..13.png    sprite completo (bola incluída)
characters/base/base_01..13.png            sprite completo sem equipamento (melhor para rig: pernas e pés inteiros)
layers/<id>/body.png          roupa, contornos, olhos, acessórios (sem pele nem cabelo)
layers/<id>/skin.png          pele em cinzento (branco = tom base) -> tingir
layers/<id>/hair.png          cabelo em cinzento -> tingir
layers/<id>/skull_fill.png    cabeça "careca" (usada ao trocar de cabelo)
layers/<id>/head_outline.png  contorno da cabeça careca
hair_library/hair_<id>.png    40 cabelos (+ hair_library.json com âncoras)
rig/<id>/head|torso|leg_l|leg_r.png   peças já cortadas (mesmo canvas 256×512)
rig/rig.json                  pivots (pescoço, ancas), linhas de corte, ordem de desenho
config/customization.json     8 tons de pele + 13 cores de cabelo
props/ball.png                bola
tools/compose.py              compõe personagem personalizado (Python/Pillow)
tools/slice_rig.py            corta QUALQUER sprite composto em peças de rig
js/CharacterCustomizer.mjs    mesma personalização em runtime (canvas/Phaser/Pixi)
previews/                     imagens de exemplo
```

## Personalização
Fórmula: `cor final = cor escolhida × camada cinzenta` (multiply). Mantém sombras e contornos.

Python:
```
python tools/compose.py casual_03 --skin tom_6_castanho --hair-style football_05 --hair-color louro -o p1.png
```
- `--hair-style original` mantém o cabelo do personagem (só muda a cor), `none` = careca,
  ou qualquer id da biblioteca (ex.: `casual_07`, `football_02`).
- `--skin` / `--hair-color` aceitam o nome da paleta ou um hex (`#8d5524`).

JS: ver exemplo no topo de `js/CharacterCustomizer.mjs`.

## Animação (rig)
Desenha as peças todas em (0,0) pela ordem de `z_order` (`leg_l, leg_r, torso, head`) e roda/move cada uma
pelo pivot em `rig.json`: `neck_pivot` (cabeça), `hip_pivot_l` / `hip_pivot_r` (pernas).
Para um personagem já personalizado: `python tools/slice_rig.py p1.png casual_03 -o p1_rig/`.
As peças têm sobreposição (cabeça sobre torso, torso sobre pernas) para não aparecerem buracos ao rodar.

## Limitações (a arte original é um desenho único, não camadas)
- A separação pele/cabelo é automática: em cabelos claros/louros ou franjas finas pode haver pequenos pixels
  fora do sítio; ao trocar de cabelo, o contorno do crânio pode aparecer um pouco por baixo de cabelos curtos.
- Os braços fazem parte da peça `torso` (não dá para separar manga de camisola sem redesenhar).
- No conjunto football a bola está dentro do sprite e tapa parte do pé esquerdo; `props/ball.png` serve para
  novas bolas, mas o pé tapado não pode ser recuperado sem redesenhar.
- Os olhos são parte do `body` (não há piscar/boca separados).
Para qualidade final de produção, o ideal é redesenhar as camadas (cabelo, cabeça sem cabelo, braços, olhos) por cima destes ficheiros.
