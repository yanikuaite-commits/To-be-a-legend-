// Personalizador de personagens (browser / Phaser / PixiJS / canvas).
// Compõe: body + pele (tingida) + [crânio + contorno + cabelo da biblioteca] e devolve um <canvas>.
// Podes usar o canvas como textura (Phaser: this.textures.addCanvas('p1', canvas)).
//
// Exemplo:
//   import { CharacterCustomizer } from './CharacterCustomizer.mjs';
//   const cc = new CharacterCustomizer('./');           // pasta raiz do pacote
//   await cc.init();
//   const canvas = await cc.build('casual_03', { skin: 'tom_6_castanho', hairStyle: 'football_05', hairColor: 'louro' });
//   document.body.appendChild(canvas);

export class CharacterCustomizer {
  constructor(root = './') {
    this.root = root.endsWith('/') ? root : root + '/';
    this.cfg = null;
    this.anchors = null;
    this.cache = new Map();
  }

  async init() {
    const [cfg, anchors] = await Promise.all([
      fetch(this.root + 'config/customization.json').then((r) => r.json()),
      fetch(this.root + 'hair_library/hair_library.json').then((r) => r.json()),
    ]);
    this.cfg = cfg;
    this.anchors = anchors;
  }

  _loadImage(path) {
    if (!this.cache.has(path)) {
      this.cache.set(
        path,
        new Promise((resolve, reject) => {
          const img = new Image();
          img.onload = () => resolve(img);
          img.onerror = () => reject(new Error('Falhou a carregar ' + path));
          img.src = this.root + path;
        })
      );
    }
    return this.cache.get(path);
  }

  _color(value) {
    if (!value) return null;
    return this.cfg.skin_tones[value] || this.cfg.hair_colors[value] || value;
  }

  // multiplica a imagem cinzenta pela cor e mantém o alpha original
  _tinted(img, color, w = img.width, h = img.height) {
    const c = document.createElement('canvas');
    c.width = w;
    c.height = h;
    const g = c.getContext('2d');
    g.drawImage(img, 0, 0);
    g.globalCompositeOperation = 'multiply';
    g.fillStyle = color;
    g.fillRect(0, 0, w, h);
    g.globalCompositeOperation = 'destination-in';
    g.drawImage(img, 0, 0);
    return c;
  }

  async build(char, { skin = null, hairStyle = 'original', hairColor = null } = {}) {
    const body = await this._loadImage(`layers/${char}/body.png`);
    const out = document.createElement('canvas');
    out.width = body.width;
    out.height = body.height;
    const g = out.getContext('2d');
    g.drawImage(body, 0, 0);

    const skinColor = this._color(skin);
    const skinImg = await this._loadImage(`layers/${char}/skin.png`);
    if (skinColor) g.drawImage(this._tinted(skinImg, skinColor), 0, 0);
    else {
      // sem tom escolhido: usa o sprite original só nas zonas de pele
      g.drawImage(await this._maskedOriginal(char, skinImg), 0, 0);
    }

    if (hairStyle === 'original') {
      const hair = await this._loadImage(`layers/${char}/hair.png`);
      const hc = this._color(hairColor);
      if (hc) g.drawImage(this._tinted(hair, hc), 0, 0);
      else g.drawImage(await this._maskedOriginal(char, hair), 0, 0);
      return out;
    }

    const fill = await this._loadImage(`layers/${char}/skull_fill.png`);
    g.drawImage(this._tinted(fill, skinColor || '#b5703f'), 0, 0);
    g.drawImage(await this._loadImage(`layers/${char}/head_outline.png`), 0, 0);

    if (hairStyle !== 'none') {
      const src = this.anchors[hairStyle];
      const dst = this.anchors[char];
      const himg = await this._loadImage('hair_library/' + src.file);
      const tinted = this._tinted(himg, this._color(hairColor) || '#1B1514');
      const dx = Math.round(dst.anchor_x - src.anchor_x);
      const dy = Math.round(dst.anchor_y - src.anchor_y);
      g.drawImage(tinted, src.crop_x + dx, src.crop_y + dy);
    }
    return out;
  }

  async _maskedOriginal(char, maskImg) {
    const folder = char.split('_')[0];
    const full = await this._loadImage(`characters/${folder}/${char}.png`);
    const c = document.createElement('canvas');
    c.width = full.width;
    c.height = full.height;
    const g = c.getContext('2d');
    g.drawImage(full, 0, 0);
    g.globalCompositeOperation = 'destination-in';
    g.drawImage(maskImg, 0, 0);
    return c;
  }
}
