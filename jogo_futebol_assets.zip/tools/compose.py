#!/usr/bin/env python3
"""Compõe um personagem personalizado a partir das camadas.

Uso (linha de comandos):
  python tools/compose.py casual_03 --skin tom_6_castanho --hair-style football_05 --hair-color louro -o out.png
  (--hair-style original  = mantém o cabelo do próprio personagem; "none" = careca)

Uso (módulo):
  from compose import compose
  img = compose('casual_03', skin='#94502C', hair_style='casual_07', hair_color='#1B1514')
"""
import json, os, sys, argparse
import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
CFG = json.load(open(os.path.join(ROOT, 'config', 'customization.json'), encoding='utf-8'))
ANCH = json.load(open(os.path.join(ROOT, 'hair_library', 'hair_library.json'), encoding='utf-8'))

def _hex(v):
    if v is None: return None
    v = CFG['skin_tones'].get(v) or CFG['hair_colors'].get(v) or v
    v = v.lstrip('#')
    return tuple(int(v[i:i + 2], 16) for i in (0, 2, 4))

def _load(char, name):
    return Image.open(os.path.join(ROOT, 'layers', char, name + '.png')).convert('RGBA')

def _tint(gray_rgba, rgb):
    a = np.array(gray_rgba).astype(np.float32)
    out = a.copy()
    for i in range(3):
        out[..., i] = a[..., i] / 255.0 * rgb[i]
    return Image.fromarray(np.clip(out, 0, 255).astype(np.uint8), 'RGBA')

def compose(char, skin=None, hair_style='original', hair_color=None):
    body = _load(char, 'body')
    canvas = Image.new('RGBA', body.size, (0, 0, 0, 0))
    canvas.alpha_composite(body)
    skin_rgb = _hex(skin)
    skin_l = _load(char, 'skin')
    canvas.alpha_composite(_tint(skin_l, skin_rgb) if skin_rgb else _original_skin(char, skin_l))
    if hair_style == 'original':
        hair = _load(char, 'hair')
        hair_rgb = _hex(hair_color)
        if hair_rgb: canvas.alpha_composite(_tint(hair, hair_rgb))
        else: canvas.alpha_composite(_original_hair(char))
        return canvas
    # cabelo diferente: crânio + contorno + cabelo da biblioteca
    sf = _load(char, 'skull_fill')
    canvas.alpha_composite(_tint(sf, skin_rgb) if skin_rgb else _tint(sf, _base_skin(char)))
    canvas.alpha_composite(_load(char, 'head_outline'))
    if hair_style != 'none':
        src = ANCH[hair_style]; dst = ANCH[char]
        himg = Image.open(os.path.join(ROOT, 'hair_library', src['file'])).convert('RGBA')
        hair_rgb = _hex(hair_color) or (40, 30, 28)
        himg = _tint(himg, hair_rgb)
        dx = round(dst['anchor_x'] - src['anchor_x']); dy = round(dst['anchor_y'] - src['anchor_y'])
        canvas.alpha_composite(himg, (max(0, src['crop_x'] + dx), max(0, src['crop_y'] + dy)))
    return canvas

# --- cores originais (quando não se escolhe tom/cor) -------------------------
def _full(char):
    folder = char.split('_')[0]
    return Image.open(os.path.join(ROOT, 'characters', folder, char + '.png')).convert('RGBA')

def _original_skin(char, skin_l):
    full = np.array(_full(char)); m = np.array(skin_l)[..., 3] > 0
    out = np.zeros_like(full); out[m] = full[m]; return Image.fromarray(out)

def _original_hair(char):
    full = np.array(_full(char)); m = np.array(_load(char, 'hair'))[..., 3] > 0
    out = np.zeros_like(full); out[m] = full[m]; return Image.fromarray(out)

def _base_skin(char):
    full = np.array(_full(char)); m = np.array(_load(char, 'skin'))[..., 3] > 0
    px = full[m][:, :3].astype(np.float32); lum = px.mean(1)
    sel = px[lum >= np.percentile(lum, 70)]
    return tuple(int(v) for v in sel.mean(0))

if __name__ == '__main__':
    p = argparse.ArgumentParser()
    p.add_argument('char'); p.add_argument('--skin'); p.add_argument('--hair-style', default='original')
    p.add_argument('--hair-color'); p.add_argument('-o', '--out', default='out.png')
    a = p.parse_args()
    compose(a.char, a.skin, a.hair_style, a.hair_color).save(a.out)
    print('guardado em', a.out)
