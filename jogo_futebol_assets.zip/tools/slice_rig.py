#!/usr/bin/env python3
"""Corta um sprite (original ou já personalizado) em peças para animação:
head, torso (com braços), leg_l, leg_r.  As peças ficam no MESMO canvas (256x512),
por isso basta desenhá-las todas em (0,0) e depois rodar/mover cada uma pelo seu pivot.

  python tools/slice_rig.py meu_personagem.png casual_03 -o saida/
"""
import json, os, sys, argparse
import numpy as np
from PIL import Image

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
RIG = json.load(open(os.path.join(ROOT, 'rig', 'rig.json'), encoding='utf-8'))

def slice_sprite(img, char):
    r = RIG[char]; a = np.array(img.convert('RGBA'))
    H, W = a.shape[:2]; cx = r['center_x']; chin = r['head_cut_y']; hip = r['hip_cut_y']
    ov_t = r['overlap_px']['torso_under_head']; ov_l = r['overlap_px']['legs_under_torso']
    # largura das pernas medida ao nível dos pés
    feet = a[470:496, :, 3] > 40
    cols = np.where(feet.any(0))[0]
    lx0, lx1 = cols.min() - 4, cols.max() + 4
    yy, xx = np.mgrid[0:H, 0:W]
    legs_zone = (xx >= lx0) & (xx <= lx1)
    parts = {}
    def make(mask):
        o = np.zeros_like(a); o[mask] = a[mask]; return Image.fromarray(o)
    parts['head'] = make(yy < chin)
    parts['torso'] = make(((yy >= chin - ov_t) & (yy < hip)) | ((yy >= hip) & ~legs_zone))
    legs = (yy >= hip - ov_l) & legs_zone
    parts['leg_l'] = make(legs & (xx < cx))
    parts['leg_r'] = make(legs & (xx >= cx))
    return parts

if __name__ == '__main__':
    p = argparse.ArgumentParser(); p.add_argument('png'); p.add_argument('char'); p.add_argument('-o', '--out', default='rig_out')
    a = p.parse_args(); os.makedirs(a.out, exist_ok=True)
    for k, v in slice_sprite(Image.open(a.png), a.char).items():
        v.save(os.path.join(a.out, k + '.png'))
    print('peças guardadas em', a.out)
